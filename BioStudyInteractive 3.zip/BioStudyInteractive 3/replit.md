# Cell Biology 383 - Interactive Study Website

## Overview
An interactive digital textbook and study platform for Cell Biology 383, Lecture 7 focusing on cellular membranes. The application provides comprehensive lecture content, an interactive mind map, and an auto-graded quiz system to enhance student learning.

## Recent Changes
- **2025-01-15**: Initial project setup with complete frontend implementation
  - Created 7 lecture sections (7.1-7.7) with comprehensive content on membrane biology
  - Implemented interactive mind map with 6 concept nodes
  - Built auto-graded quiz system with 30 multiple-choice questions
  - Configured blue-and-white academic design theme
  - Set up responsive sidebar navigation

## Project Architecture

### Frontend Structure
- **React SPA** with Wouter for routing
- **Tailwind CSS** with custom academic design tokens
- **Shadcn UI** components for consistent styling
- **Font Stack**: Inter (headings), Lora/Georgia (body text)

### Key Features
1. **Lecture Sections (7.1-7.7)**
   - Introduction to membranes
   - Functions of membranes
   - Membrane lipids
   - Membrane proteins
   - Fluidity and asymmetry
   - Dynamics and transport
   - Experimental insights

2. **Interactive Mind Map**
   - 6 clickable concept nodes: Lipids, Proteins, Carbohydrates, Fluidity, Transport, Signaling
   - Detailed information panels for each concept
   - Visual icons and color coding

3. **Auto-Graded Quiz**
   - 30 comprehensive multiple-choice questions
   - Instant feedback with explanations
   - Progress tracking
   - Score calculation and review options

### Data Models
- Quiz questions stored in `client/src/data/quiz-questions.ts`
- Lecture content in `client/src/data/lecture-content.ts` and `lecture-content-extended.ts`
- Schema definitions in `shared/schema.ts`

### Navigation
- Persistent sidebar with section links
- Previous/Next navigation between sections
- Home page with overview and quick access cards

## Design Guidelines
- Academic blue-and-white color scheme
- Readable typography with serif fonts for body text
- Responsive design for desktop, tablet, and mobile
- Figure placeholders for scientific diagrams
- Accessible with proper ARIA labels and semantic HTML

## User Preferences
- Clean, professional academic aesthetic
- Content-first approach with minimal distractions
- Interactive elements for engagement
- Immediate feedback on quizzes

## Tech Stack
- **Frontend**: React, TypeScript, Tailwind CSS, Shadcn UI
- **Routing**: Wouter
- **State Management**: React Query
- **Backend**: Express.js (Node.js)
- **Storage**: In-memory storage (MemStorage)

## Development Status
- ✅ Frontend components complete
- ✅ Quiz data and questions ready
- ✅ Lecture content integrated
- ✅ Mind map implemented
- ⏳ Backend API for quiz grading (pending)
- ⏳ Integration and testing (pending)
