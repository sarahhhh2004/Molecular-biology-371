import { 
  BookOpen, 
  Brain, 
  ClipboardCheck, 
  Home,
  Microscope,
  Atom,
  FlaskConical,
  Layers,
  Zap,
  Network,
  TestTube,
  TrendingUp
} from "lucide-react";
import { Link, useLocation } from "wouter";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";

const sections = [
  {
    title: "Overview",
    url: "/",
    icon: Home,
  },
  {
    title: "7.1 Introduction",
    url: "/section/7.1",
    icon: BookOpen,
  },
  {
    title: "7.2 Functions of Membranes",
    url: "/section/7.2",
    icon: Layers,
  },
  {
    title: "7.3 Membrane Lipids",
    url: "/section/7.3",
    icon: Atom,
  },
  {
    title: "7.4 Membrane Proteins",
    url: "/section/7.4",
    icon: FlaskConical,
  },
  {
    title: "7.5 Fluidity and Asymmetry",
    url: "/section/7.5",
    icon: Zap,
  },
  {
    title: "7.6 Dynamics and Transport",
    url: "/section/7.6",
    icon: Network,
  },
  {
    title: "7.7 Experimental Insights",
    url: "/section/7.7",
    icon: TestTube,
  },
];

const tools = [
  {
    title: "Interactive Mind Map",
    url: "/mindmap",
    icon: Brain,
  },
  {
    title: "Lecture Quiz",
    url: "/quiz",
    icon: ClipboardCheck,
  },
  {
    title: "Your Progress",
    url: "/progress",
    icon: TrendingUp,
  },
];

export function AppSidebar() {
  const [location] = useLocation();

  return (
    <Sidebar>
      <SidebarHeader className="p-6 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 rounded-md bg-primary">
            <Microscope className="w-6 h-6 text-primary-foreground" />
          </div>
          <div>
            <h2 className="text-base font-semibold text-sidebar-foreground">Cell Biology 383</h2>
            <p className="text-sm text-muted-foreground">Lecture 7</p>
          </div>
        </div>
      </SidebarHeader>
      
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="text-xs font-semibold uppercase tracking-wider text-muted-foreground px-3">
            Lecture Sections
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {sections.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton 
                    asChild 
                    isActive={location === item.url}
                    data-testid={`link-${item.url.replace(/\//g, '-').slice(1) || 'home'}`}
                    className="hover-elevate"
                  >
                    <Link href={item.url}>
                      <item.icon className="w-4 h-4" />
                      <span className="text-sm">{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className="text-xs font-semibold uppercase tracking-wider text-muted-foreground px-3">
            Study Tools
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {tools.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton 
                    asChild 
                    isActive={location === item.url}
                    data-testid={`link-${item.url.slice(1)}`}
                    className="hover-elevate"
                  >
                    <Link href={item.url}>
                      <item.icon className="w-4 h-4" />
                      <span className="text-sm">{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4 border-t border-sidebar-border">
        <p className="text-xs text-muted-foreground text-center">
          © 2025 Cell Biology 383
        </p>
      </SidebarFooter>
    </Sidebar>
  );
}
