import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Droplet, 
  Box, 
  Candy, 
  Zap, 
  ArrowRightLeft, 
  Radio,
  Info
} from "lucide-react";

interface MindMapNode {
  id: string;
  title: string;
  description: string;
  detailedInfo: string;
  icon: React.ElementType;
  color: string;
}

const nodes: MindMapNode[] = [
  {
    id: "lipids",
    title: "Lipids",
    description: "Lipids form the hydrophobic core and polar surface",
    detailedInfo: "Lipids are the primary structural component of membranes, forming the lipid bilayer. They include phospholipids, glycolipids, and sterols (like cholesterol). These amphipathic molecules have both hydrophobic tails and hydrophilic heads, driving spontaneous bilayer formation in aqueous environments. The composition of lipids determines membrane fluidity, permeability, and functional properties.",
    icon: Droplet,
    color: "bg-blue-500/10 border-blue-500/20 hover:border-blue-500/40"
  },
  {
    id: "proteins",
    title: "Proteins",
    description: "Integral and peripheral proteins perform key functions",
    detailedInfo: "Membrane proteins carry out most membrane functions. Integral proteins span the bilayer and include channels, carriers, and receptors. Peripheral proteins attach to membrane surfaces. Together they perform transport, catalysis, signal transduction, cell recognition, and structural support. The fluid mosaic model describes proteins floating within the lipid bilayer.",
    icon: Box,
    color: "bg-purple-500/10 border-purple-500/20 hover:border-purple-500/40"
  },
  {
    id: "carbohydrates",
    title: "Carbohydrates",
    description: "Carbohydrates attach to proteins and lipids for recognition",
    detailedInfo: "Carbohydrates are attached to proteins (glycoproteins) and lipids (glycolipids) on the extracellular surface of membranes. They serve as recognition markers for cell identity, immune responses, and cell-cell interactions. Glycocalyx formed by these carbohydrates protects cells and mediates interactions with the environment and other cells.",
    icon: Candy,
    color: "bg-pink-500/10 border-pink-500/20 hover:border-pink-500/40"
  },
  {
    id: "fluidity",
    title: "Fluidity",
    description: "Membrane fluidity depends on lipid composition and temperature",
    detailedInfo: "Membrane fluidity allows lateral movement of lipids and proteins. It depends on fatty acid saturation, cholesterol content, and temperature. Unsaturated fatty acids increase fluidity by preventing tight packing. Cholesterol acts as a fluidity buffer, preventing extremes. The transition temperature (Tm) marks the shift from gel to fluid state. Cells adjust lipid composition to maintain optimal fluidity.",
    icon: Zap,
    color: "bg-yellow-500/10 border-yellow-500/20 hover:border-yellow-500/40"
  },
  {
    id: "transport",
    title: "Transport",
    description: "Selective permeability allows essential molecules through",
    detailedInfo: "Membranes regulate molecular traffic through various transport mechanisms. Passive transport (simple and facilitated diffusion) moves molecules down gradients without energy. Active transport uses ATP to move molecules against gradients via pumps like Na⁺/K⁺-ATPase. Vesicular transport (endocytosis/exocytosis) handles large molecules and particles. This selective permeability maintains cellular homeostasis.",
    icon: ArrowRightLeft,
    color: "bg-green-500/10 border-green-500/20 hover:border-green-500/40"
  },
  {
    id: "signaling",
    title: "Signaling",
    description: "Signal molecules bind receptors triggering cellular responses",
    detailedInfo: "Membrane receptors detect external signals (hormones, neurotransmitters, growth factors) and transmit information to the cell interior through signal transduction pathways. This process involves receptor binding, conformational changes, and activation of intracellular cascades. Signaling regulates cell growth, differentiation, metabolism, and responses to environmental changes.",
    icon: Radio,
    color: "bg-orange-500/10 border-orange-500/20 hover:border-orange-500/40"
  }
];

export default function MindMap() {
  const [selectedNode, setSelectedNode] = useState<MindMapNode | null>(null);

  return (
    <div className="w-full max-w-6xl mx-auto px-6 py-12 md:py-16">
      <div className="space-y-8">
        <div className="space-y-4">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground">
            Interactive Mind Map
          </h1>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Explore the key concepts of membrane biology. Click on any node to learn more about that concept.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {nodes.map((node) => {
            const Icon = node.icon;
            const isSelected = selectedNode?.id === node.id;
            
            return (
              <Card
                key={node.id}
                className={`cursor-pointer transition-all duration-200 ${node.color} ${
                  isSelected ? 'ring-2 ring-primary shadow-lg' : ''
                } hover-elevate active-elevate-2`}
                onClick={() => setSelectedNode(node)}
                data-testid={`node-${node.id}`}
              >
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="flex items-center justify-center w-12 h-12 rounded-md bg-primary/10">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                    <CardTitle className="text-xl">{node.title}</CardTitle>
                  </div>
                  <CardDescription className="text-base">
                    {node.description}
                  </CardDescription>
                </CardHeader>
              </Card>
            );
          })}
        </div>

        {selectedNode ? (
          <Card className="mt-8 border-2 border-primary/20 bg-primary/5" data-testid="info-panel">
            <CardHeader>
              <div className="flex items-center gap-3 mb-2">
                <div className="flex items-center justify-center w-12 h-12 rounded-md bg-primary">
                  {selectedNode.icon && <selectedNode.icon className="w-6 h-6 text-primary-foreground" />}
                </div>
                <CardTitle className="text-2xl">{selectedNode.title}</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-base md:text-lg leading-relaxed text-foreground font-serif">
                {selectedNode.detailedInfo}
              </p>
              <Button
                variant="outline"
                onClick={() => setSelectedNode(null)}
                className="mt-6"
                data-testid="button-close-info"
              >
                Close
              </Button>
            </CardContent>
          </Card>
        ) : (
          <Card className="mt-8 border-2 border-dashed border-border bg-muted/30">
            <CardContent className="flex items-center justify-center py-12">
              <div className="text-center space-y-3">
                <div className="flex justify-center">
                  <div className="flex items-center justify-center w-16 h-16 rounded-full bg-muted">
                    <Info className="w-8 h-8 text-muted-foreground" />
                  </div>
                </div>
                <p className="text-lg text-muted-foreground">
                  Click on a concept node above to see detailed information
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
