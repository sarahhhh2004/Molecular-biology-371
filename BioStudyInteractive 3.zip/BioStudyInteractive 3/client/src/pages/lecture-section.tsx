import { useParams, Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, FileText } from "lucide-react";
import { lectureData } from "@/data/lecture-content";
import { lectureData75, lectureData76, lectureData77 } from "@/data/lecture-content-extended";

import lipidBilayerImg from "@assets/generated_images/Lipid_bilayer_structure_diagram_46d06ec1.png";
import membraneProteinsImg from "@assets/generated_images/Membrane_protein_types_diagram_1e8522c4.png";
import passiveTransportImg from "@assets/generated_images/Passive_transport_mechanisms_diagram_1731b67f.png";
import sodiumPotassiumPumpImg from "@assets/generated_images/Sodium_potassium_pump_diagram_bda0b120.png";
import membraneFluidityImg from "@assets/generated_images/Membrane_fluidity_visualization_1b7947bd.png";
import lipidRaftsImg from "@assets/generated_images/Lipid_raft_microdomains_diagram_f1de74b4.png";
import receptorEndocytosisImg from "@assets/generated_images/Receptor_mediated_endocytosis_process_c20416c9.png";
import frapTechniqueImg from "@assets/generated_images/FRAP_technique_illustration_a6dd32d1.png";
import freezeFractureImg from "@assets/generated_images/Freeze_fracture_microscopy_diagram_6af5b679.png";
import membraneAsymmetryImg from "@assets/generated_images/Membrane_asymmetry_visualization_3f4be5b6.png";
import aquaporinImg from "@assets/generated_images/Aquaporin_water_channel_structure_3e34341f.png";
import symportAntiportImg from "@assets/generated_images/Symport_and_antiport_transporters_25449000.png";
import glycocalyxImg from "@assets/generated_images/Glycocalyx_structure_and_function_31e55da3.png";
import fluidMosaicImg from "@assets/generated_images/Fluid_mosaic_model_overview_54be62c2.png";
import phagocytosisImg from "@assets/generated_images/Phagocytosis_cell_eating_process_f7f9ee1f.png";

// Figure number to image mapping
const figureImages: Record<string, string> = {
  "7-1": lipidBilayerImg,
  "7-2": fluidMosaicImg,
  "7-3": membraneProteinsImg,
  "7-4": membraneFluidityImg,
  "7-5": lipidBilayerImg,
  "7-6": fluidMosaicImg,
  "7-7": membraneProteinsImg,
  "7-8": glycocalyxImg,
  "7-9": membraneFluidityImg,
  "7-10": membraneFluidityImg,
  "7-11": membraneAsymmetryImg,
  "7-12": lipidRaftsImg,
  "7-13": passiveTransportImg,
  "7-14": aquaporinImg,
  "7-15": sodiumPotassiumPumpImg,
  "7-15A": symportAntiportImg,
  "7-16": receptorEndocytosisImg,
  "7-16A": phagocytosisImg,
  "7-17": lipidBilayerImg,
  "7-18": freezeFractureImg,
  "7-19": frapTechniqueImg,
  "7-20": membraneProteinsImg,
  "7-21": lipidBilayerImg
};

const allLectureData: Record<string, any> = {
  ...lectureData,
  "7.5": lectureData75,
  "7.6": lectureData76,
  "7.7": lectureData77,
};

const sectionOrder = ["7.1", "7.2", "7.3", "7.4", "7.5", "7.6", "7.7"];

export default function LectureSection() {
  const params = useParams();
  const sectionId = params.id || "7.1";
  const section = allLectureData[sectionId];

  if (!section) {
    return (
      <div className="w-full max-w-4xl mx-auto px-6 py-12">
        <Card className="p-8 text-center">
          <h2 className="text-2xl font-semibold mb-2">Section Not Found</h2>
          <p className="text-muted-foreground mb-6">
            The requested lecture section could not be found.
          </p>
          <Link href="/">
            <Button>Return to Home</Button>
          </Link>
        </Card>
      </div>
    );
  }

  const currentIndex = sectionOrder.indexOf(sectionId);
  const prevSection = currentIndex > 0 ? sectionOrder[currentIndex - 1] : null;
  const nextSection = currentIndex < sectionOrder.length - 1 ? sectionOrder[currentIndex + 1] : null;

  return (
    <div className="w-full max-w-4xl mx-auto px-6 py-12 md:py-16">
      <article className="space-y-8 font-serif">
        <header className="space-y-4 pb-6 border-b border-border">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-sans font-medium">
            <FileText className="w-4 h-4" />
            Section {sectionId}
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-foreground font-sans">
            {section.title}
          </h1>
          {section.subtitle && (
            <p className="text-xl text-muted-foreground italic">
              {section.subtitle}
            </p>
          )}
        </header>

        <div className="prose prose-lg max-w-none">
          {section.intro && (
            <p className="text-lg leading-relaxed text-foreground mb-6">
              {section.intro}
            </p>
          )}

          {section.content && Array.isArray(section.content) && section.content.map((para: string, idx: number) => (
            <p key={idx} className="text-base md:text-lg leading-relaxed text-foreground mb-6">
              {para}
            </p>
          ))}

          {section.mainContent && (
            <p className="text-base md:text-lg leading-relaxed text-foreground mb-6">
              {section.mainContent}
            </p>
          )}

          {section.sections && section.sections.map((subsection: any, idx: number) => (
            <div key={idx} className="my-8">
              <h3 className="text-2xl font-semibold text-foreground mb-4 font-sans">
                {subsection.title}
              </h3>
              {subsection.content && (
                Array.isArray(subsection.content) ? (
                  subsection.content.map((para: string, pIdx: number) => (
                    <p key={pIdx} className="text-base md:text-lg leading-relaxed text-foreground mb-4">
                      {para}
                    </p>
                  ))
                ) : (
                  <p className="text-base md:text-lg leading-relaxed text-foreground mb-4">
                    {subsection.content}
                  </p>
                )
              )}
              {subsection.listItems && (
                <ul className="space-y-3 mb-4 ml-6">
                  {subsection.listItems.map((item: string, liIdx: number) => (
                    <li key={liIdx} className="text-base md:text-lg leading-relaxed text-foreground">
                      <strong className="text-foreground">{item.split(':')[0]}:</strong>
                      {item.includes(':') ? item.substring(item.indexOf(':') + 1) : ''}
                    </li>
                  ))}
                </ul>
              )}
              {subsection.additionalContent && (
                Array.isArray(subsection.additionalContent) ? (
                  subsection.additionalContent.map((para: string, aIdx: number) => (
                    <p key={aIdx} className="text-base md:text-lg leading-relaxed text-foreground mb-4">
                      {para}
                    </p>
                  ))
                ) : (
                  <p className="text-base md:text-lg leading-relaxed text-foreground mb-4">
                    {subsection.additionalContent}
                  </p>
                )
              )}
            </div>
          ))}

          {section.conclusion && (
            <p className="text-base md:text-lg leading-relaxed text-foreground my-8 font-medium">
              {section.conclusion}
            </p>
          )}

          {section.tables && section.tables.map((table: any, tIdx: number) => (
            <div key={tIdx} className="my-8 overflow-x-auto">
              <table className="w-full border-collapse border border-border">
                <thead>
                  <tr className="bg-muted">
                    {table.headers.map((header: string, hIdx: number) => (
                      <th key={hIdx} className="border border-border px-4 py-3 text-left font-semibold text-foreground">
                        {header}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {table.rows.map((row: string[], rIdx: number) => (
                    <tr key={rIdx} className={rIdx % 2 === 0 ? 'bg-card' : 'bg-background'}>
                      {row.map((cell: string, cIdx: number) => (
                        <td key={cIdx} className="border border-border px-4 py-3 text-foreground">
                          {cell}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ))}

          {section.figures && section.figures.length > 0 && (
            <div className="space-y-6 my-12">
              {section.figures.map((figure: any, fIdx: number) => {
                const imageSrc = figureImages[figure.number];
                return (
                  <Card key={fIdx} className="p-6 border border-border bg-card" data-testid={`figure-${figure.number}`}>
                    {imageSrc ? (
                      <div className="mb-4 rounded-md overflow-hidden bg-background">
                        <img 
                          src={imageSrc} 
                          alt={`Figure ${figure.number}: ${figure.caption}`}
                          className="w-full h-auto"
                        />
                      </div>
                    ) : (
                      <div className="flex items-center justify-center h-48 mb-4 bg-background/50 rounded-md border-2 border-dashed border-border">
                        <p className="text-sm text-muted-foreground italic">
                          Figure {figure.number} will appear here
                        </p>
                      </div>
                    )}
                    <p className="text-sm text-muted-foreground text-center leading-relaxed">
                      <strong className="text-foreground">Figure {figure.number}:</strong> {figure.caption}
                    </p>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </article>

      <div className="flex items-center justify-between mt-12 pt-8 border-t border-border gap-4">
        {prevSection ? (
          <Link href={`/section/${prevSection}`}>
            <Button variant="outline" className="gap-2" data-testid={`button-prev-${prevSection}`}>
              <ChevronLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Previous: </span>Section {prevSection}
            </Button>
          </Link>
        ) : (
          <div />
        )}

        {nextSection ? (
          <Link href={`/section/${nextSection}`}>
            <Button className="gap-2" data-testid={`button-next-${nextSection}`}>
              <span className="hidden sm:inline">Next: </span>Section {nextSection}
              <ChevronRight className="w-4 h-4" />
            </Button>
          </Link>
        ) : (
          <Link href="/quiz">
            <Button className="gap-2" data-testid="button-take-quiz">
              Take Quiz
              <ChevronRight className="w-4 h-4" />
            </Button>
          </Link>
        )}
      </div>
    </div>
  );
}
