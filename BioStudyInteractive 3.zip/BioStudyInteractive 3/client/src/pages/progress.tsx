import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, Trophy, Clock, BookOpen, BarChart3, Calendar } from "lucide-react";
import { Link } from "wouter";
import type { QuizAttempt, SectionProgress } from "@shared/schema";

interface QuizStats {
  totalAttempts: number;
  averageScore: number;
  bestScore: number;
}

export default function ProgressPage() {
  const { data: quizAttempts, isLoading: attemptsLoading } = useQuery<QuizAttempt[]>({
    queryKey: ["/api/progress/quiz"],
  });

  const { data: stats, isLoading: statsLoading } = useQuery<QuizStats>({
    queryKey: ["/api/progress/stats"],
  });

  const { data: sectionProgress, isLoading: sectionsLoading } = useQuery<SectionProgress[]>({
    queryKey: ["/api/progress/sections"],
  });

  const totalTimeSpent = sectionProgress?.reduce((sum, s) => sum + s.timeSpent, 0) || 0;
  const sectionsVisited = sectionProgress?.length || 0;
  const sectionsCompleted = sectionProgress?.filter(s => s.completed).length || 0;

  return (
    <div className="w-full max-w-6xl mx-auto px-6 py-12 md:py-16">
      <div className="space-y-8">
        <header className="space-y-4">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground">
            Your Progress
          </h1>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Track your learning journey through Cell Biology 383
          </p>
        </header>

        {/* Stats Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Quiz Attempts</CardTitle>
              <BarChart3 className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.totalAttempts || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Total quiz submissions
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Average Score</CardTitle>
              <TrendingUp className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.averageScore || 0}%</div>
              <p className="text-xs text-muted-foreground mt-1">
                Across all attempts
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Best Score</CardTitle>
              <Trophy className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.bestScore || 0}%</div>
              <p className="text-xs text-muted-foreground mt-1">
                Personal best
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Study Time</CardTitle>
              <Clock className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {Math.round(totalTimeSpent / 60)}m
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Total time spent
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Section Progress */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3 mb-2">
              <div className="flex items-center justify-center w-10 h-10 rounded-md bg-primary/10">
                <BookOpen className="w-5 h-5 text-primary" />
              </div>
              <div>
                <CardTitle className="text-xl">Section Progress</CardTitle>
                <CardDescription>
                  {sectionsCompleted} of 7 sections completed
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <Progress value={(sectionsCompleted / 7) * 100} className="h-2" />
            
            {sectionsLoading ? (
              <p className="text-sm text-muted-foreground">Loading section progress...</p>
            ) : sectionProgress && sectionProgress.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                {["7.1", "7.2", "7.3", "7.4", "7.5", "7.6", "7.7"].map((sectionId) => {
                  const progress = sectionProgress.find(s => s.sectionId === sectionId);
                  return (
                    <div key={sectionId} className="flex items-center justify-between p-4 rounded-md border border-border bg-card">
                      <div className="flex items-center gap-3">
                        <div className={`flex items-center justify-center w-8 h-8 rounded-md ${progress?.completed ? 'bg-green-100 dark:bg-green-950' : 'bg-muted'}`}>
                          <span className="text-sm font-semibold">
                            {sectionId}
                          </span>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Section {sectionId}</p>
                          {progress && (
                            <p className="text-xs text-muted-foreground">
                              {Math.round(progress.timeSpent / 60)}m spent
                            </p>
                          )}
                        </div>
                      </div>
                      {progress?.completed && (
                        <Badge variant="default" className="text-xs">
                          Completed
                        </Badge>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground mb-4">
                  No section progress yet. Start exploring the lectures!
                </p>
                <Link href="/section/7.1">
                  <Button>Go to Section 7.1</Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Quiz Attempts */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3 mb-2">
              <div className="flex items-center justify-center w-10 h-10 rounded-md bg-primary/10">
                <Calendar className="w-5 h-5 text-primary" />
              </div>
              <div>
                <CardTitle className="text-xl">Recent Quiz Attempts</CardTitle>
                <CardDescription>Your latest quiz submissions</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {attemptsLoading ? (
              <p className="text-sm text-muted-foreground">Loading quiz attempts...</p>
            ) : quizAttempts && quizAttempts.length > 0 ? (
              <div className="space-y-3">
                {quizAttempts.map((attempt) => (
                  <div key={attempt.id} className="flex items-center justify-between p-4 rounded-md border border-border bg-card">
                    <div className="flex items-center gap-4">
                      <div className={`flex items-center justify-center w-12 h-12 rounded-md ${
                        attempt.percentage >= 80 ? 'bg-green-100 dark:bg-green-950' :
                        attempt.percentage >= 60 ? 'bg-yellow-100 dark:bg-yellow-950' :
                        'bg-red-100 dark:bg-red-950'
                      }`}>
                        <span className="text-lg font-bold">
                          {attempt.percentage}%
                        </span>
                      </div>
                      <div>
                        <p className="text-sm font-medium">
                          Score: {attempt.score} / {attempt.totalQuestions}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(attempt.timestamp).toLocaleDateString()} at{" "}
                          {new Date(attempt.timestamp).toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                    <Badge 
                      variant={attempt.percentage >= 80 ? "default" : attempt.percentage >= 60 ? "secondary" : "destructive"}
                    >
                      {attempt.percentage >= 80 ? "Excellent" : attempt.percentage >= 60 ? "Good" : "Needs Review"}
                    </Badge>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground mb-4">
                  No quiz attempts yet. Test your knowledge!
                </p>
                <Link href="/quiz">
                  <Button>Take the Quiz</Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
