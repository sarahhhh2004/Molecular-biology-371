import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { CheckCircle2, XCircle, RotateCcw, Trophy, BookOpen, Loader2, AlertCircle } from "lucide-react";
import { Link } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { QuizQuestion, QuizResult } from "@shared/schema";

export default function Quiz() {
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [result, setResult] = useState<QuizResult | null>(null);
  const { toast } = useToast();

  // Fetch quiz questions from API
  const { data: questions, isLoading, error } = useQuery<QuizQuestion[]>({
    queryKey: ["/api/quiz/questions"],
  });

  // Submit quiz mutation
  const submitMutation = useMutation({
    mutationFn: async (submission: Record<string, number>) => {
      return await apiRequest<QuizResult>("POST", "/api/quiz/submit", { answers: submission });
    },
    onSuccess: (data: QuizResult) => {
      setResult(data);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      toast({
        title: "Quiz Submitted!",
        description: `You scored ${data.score} out of ${data.totalQuestions} (${data.percentage.toFixed(0)}%)`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Submission Failed",
        description: error.message || "There was an error submitting your quiz. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleAnswerChange = (questionId: string, answerIndex: number) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: answerIndex
    }));
  };

  const handleSubmit = () => {
    submitMutation.mutate(answers);
  };

  const handleReset = () => {
    setAnswers({});
    setResult(null);
    submitMutation.reset();
    queryClient.invalidateQueries({ queryKey: ["/api/quiz/questions"] });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (isLoading) {
    return (
      <div className="w-full max-w-4xl mx-auto px-6 py-12 md:py-16">
        <Card className="p-12">
          <CardContent className="flex flex-col items-center justify-center gap-4">
            <Loader2 className="w-12 h-12 animate-spin text-primary" />
            <p className="text-lg text-muted-foreground">Loading quiz questions...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full max-w-4xl mx-auto px-6 py-12 md:py-16">
        <Card className="border-2 border-destructive/50 bg-destructive/5">
          <CardContent className="flex flex-col items-center justify-center gap-4 p-12">
            <AlertCircle className="w-12 h-12 text-destructive" />
            <h2 className="text-2xl font-semibold text-foreground">Failed to Load Quiz</h2>
            <p className="text-muted-foreground text-center max-w-md">
              {error instanceof Error ? error.message : "There was an error loading the quiz questions. Please try again later."}
            </p>
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/quiz/questions"] })}>
                Retry
              </Button>
              <Link href="/">
                <Button>Return to Home</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!questions || questions.length === 0) {
    return (
      <div className="w-full max-w-4xl mx-auto px-6 py-12 md:py-16">
        <Card>
          <CardContent className="flex flex-col items-center justify-center gap-4 p-12">
            <p className="text-lg text-muted-foreground">No quiz questions available.</p>
            <Link href="/">
              <Button>Return to Home</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const answeredCount = Object.keys(answers).length;
  const progressPercentage = (answeredCount / questions.length) * 100;
  const scorePercentage = result ? (result.score / result.totalQuestions) * 100 : 0;

  return (
    <div className="w-full max-w-4xl mx-auto px-6 py-12 md:py-16">
      <div className="space-y-8">
        <div className="space-y-4">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground">
            Lecture Quiz
          </h1>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Test your understanding of membrane biology with {questions.length} comprehensive questions. 
            Each question has one correct answer. Read carefully and select your best response.
          </p>
        </div>

        {result && (
          <Card className="border-2 border-primary bg-primary/5" data-testid="result-card">
            <CardHeader>
              <div className="flex items-center gap-3 mb-2">
                <div className="flex items-center justify-center w-12 h-12 rounded-md bg-primary">
                  <Trophy className="w-6 h-6 text-primary-foreground" />
                </div>
                <CardTitle className="text-2xl">Quiz Results</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-3xl font-bold text-foreground">
                  {result.score} / {result.totalQuestions}
                </p>
                <p className="text-lg text-muted-foreground">
                  {scorePercentage.toFixed(0)}% correct
                </p>
              </div>
              <Progress value={scorePercentage} className="h-3" />
              <div className="flex flex-wrap gap-3 pt-4">
                <Button 
                  onClick={handleReset} 
                  variant="default"
                  className="gap-2"
                  data-testid="button-retake-quiz"
                >
                  <RotateCcw className="w-4 h-4" />
                  Retake Quiz
                </Button>
                <Link href="/section/7.1">
                  <Button variant="outline" className="gap-2">
                    <BookOpen className="w-4 h-4" />
                    Review Lecture
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        )}

        {!result && (
          <Card className="border-2 border-primary/20">
            <CardHeader>
              <CardTitle className="text-lg">Progress</CardTitle>
              <CardDescription>
                {answeredCount} of {questions.length} questions answered
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Progress value={progressPercentage} className="h-2" />
            </CardContent>
          </Card>
        )}

        <div className="space-y-6">
          {questions.map((question, index) => {
            const userAnswer = answers[question.id];
            const isCorrect = result && result.correctAnswers.includes(question.id);
            const incorrectAnswer = result?.incorrectAnswers.find(ia => ia.questionId === question.id);
            const isIncorrect = !!incorrectAnswer;

            return (
              <Card 
                key={question.id}
                className={`transition-all duration-200 ${
                  isCorrect ? 'border-green-500/50 bg-green-50/50 dark:bg-green-950/20' : 
                  isIncorrect ? 'border-red-500/50 bg-red-50/50 dark:bg-red-950/20' : 
                  ''
                }`}
                data-testid={`question-${question.id}`}
              >
                <CardHeader>
                  <div className="flex items-start justify-between gap-4">
                    <CardTitle className="text-lg font-semibold">
                      <span className="text-muted-foreground mr-2">Question {index + 1}.</span>
                      {question.question}
                    </CardTitle>
                    {result && isCorrect && (
                      <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0" data-testid={`icon-correct-${question.id}`} />
                    )}
                    {result && isIncorrect && (
                      <XCircle className="w-6 h-6 text-red-600 flex-shrink-0" data-testid={`icon-incorrect-${question.id}`} />
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <RadioGroup
                    value={userAnswer?.toString()}
                    onValueChange={(value) => handleAnswerChange(question.id, parseInt(value))}
                    disabled={!!result}
                    className="space-y-3"
                  >
                    {question.options.map((option, optionIndex) => {
                      const isThisCorrect = result && incorrectAnswer && optionIndex === incorrectAnswer.correctAnswer;
                      const isSelected = userAnswer === optionIndex;

                      return (
                        <div
                          key={optionIndex}
                          className={`flex items-start space-x-3 p-4 rounded-md border transition-colors ${
                            isThisCorrect ? 'bg-green-100/50 dark:bg-green-950/30 border-green-500/50' :
                            result && isSelected && isIncorrect ? 'bg-red-100/50 dark:bg-red-950/30 border-red-500/50' :
                            'bg-card border-border hover:bg-muted/50'
                          }`}
                          data-testid={`option-${question.id}-${optionIndex}`}
                        >
                          <RadioGroupItem 
                            value={optionIndex.toString()} 
                            id={`${question.id}-${optionIndex}`}
                            className="mt-1"
                          />
                          <Label 
                            htmlFor={`${question.id}-${optionIndex}`}
                            className="flex-1 cursor-pointer text-base leading-relaxed"
                          >
                            {option}
                          </Label>
                        </div>
                      );
                    })}
                  </RadioGroup>

                  {result && incorrectAnswer && (
                    <div className="mt-4 p-4 rounded-md bg-muted/50 border border-border">
                      <p className="text-sm font-semibold text-foreground mb-2">Explanation:</p>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {incorrectAnswer.explanation}
                      </p>
                    </div>
                  )}
                  
                  {result && isCorrect && (
                    <div className="mt-4 p-4 rounded-md bg-green-100/50 dark:bg-green-950/30 border border-green-500/50">
                      <p className="text-sm font-semibold text-foreground">✓ Correct!</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {!result && (
          <Card className="sticky bottom-4 border-2 border-primary/30 bg-background/95 backdrop-blur">
            <CardContent className="py-6">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">
                    {answeredCount === questions.length ? (
                      "All questions answered! Ready to submit?"
                    ) : (
                      `${questions.length - answeredCount} question${questions.length - answeredCount !== 1 ? 's' : ''} remaining`
                    )}
                  </p>
                  {submitMutation.isError && (
                    <p className="text-sm text-destructive mt-1">
                      Submission failed. Please try again.
                    </p>
                  )}
                </div>
                <Button
                  onClick={handleSubmit}
                  disabled={answeredCount < questions.length || submitMutation.isPending}
                  size="lg"
                  className="w-full sm:w-auto gap-2"
                  data-testid="button-submit-quiz"
                >
                  {submitMutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
                  {submitMutation.isPending ? "Submitting..." : "Submit Quiz"}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
