import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookOpen, Brain, ClipboardCheck, ArrowRight } from "lucide-react";

export default function HomePage() {
  return (
    <div className="w-full max-w-5xl mx-auto px-6 py-12 md:py-16">
      <div className="space-y-6">
        <div className="space-y-4">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground">
            Cell Biology 383
          </h1>
          <h2 className="text-2xl md:text-3xl font-semibold text-primary">
            Lecture 7: Membranes
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed max-w-3xl">
            Welcome to an interactive study platform for understanding cellular membranes. 
            This digital textbook transforms complex biological concepts into an engaging learning experience 
            with comprehensive lecture notes, interactive visualizations, and self-assessment tools.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-3 pt-8">
          <Card className="hover-elevate transition-all duration-200" data-testid="card-lecture-sections">
            <CardHeader>
              <div className="flex items-center justify-center w-12 h-12 rounded-md bg-primary/10 mb-4">
                <BookOpen className="w-6 h-6 text-primary" />
              </div>
              <CardTitle className="text-xl">Lecture Sections</CardTitle>
              <CardDescription className="text-base">
                Seven comprehensive sections covering membrane structure, function, and chemistry
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/section/7.1">
                <Button variant="outline" className="w-full" data-testid="button-start-reading">
                  Start Reading
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover-elevate transition-all duration-200" data-testid="card-mind-map">
            <CardHeader>
              <div className="flex items-center justify-center w-12 h-12 rounded-md bg-primary/10 mb-4">
                <Brain className="w-6 h-6 text-primary" />
              </div>
              <CardTitle className="text-xl">Interactive Mind Map</CardTitle>
              <CardDescription className="text-base">
                Explore membrane concepts through clickable nodes and visual connections
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/mindmap">
                <Button variant="outline" className="w-full" data-testid="button-explore-mindmap">
                  Explore Mind Map
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover-elevate transition-all duration-200" data-testid="card-quiz">
            <CardHeader>
              <div className="flex items-center justify-center w-12 h-12 rounded-md bg-primary/10 mb-4">
                <ClipboardCheck className="w-6 h-6 text-primary" />
              </div>
              <CardTitle className="text-xl">Lecture Quiz</CardTitle>
              <CardDescription className="text-base">
                Test your knowledge with 30 auto-graded questions and instant feedback
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/quiz">
                <Button variant="outline" className="w-full" data-testid="button-take-quiz">
                  Take Quiz
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        <div className="pt-8 space-y-4">
          <h3 className="text-2xl font-semibold text-foreground">What You'll Learn</h3>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <h4 className="font-semibold text-lg text-foreground">Core Concepts</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>Membrane structure and the lipid bilayer organization</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>Essential functions of biological membranes</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>Phospholipids, glycolipids, and sterols composition</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>Integral and peripheral membrane proteins</span>
                </li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold text-lg text-foreground">Advanced Topics</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>Membrane fluidity and asymmetry mechanisms</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>Transport processes across membranes</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>Experimental techniques in membrane research</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>Modern imaging and spectroscopy methods</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
