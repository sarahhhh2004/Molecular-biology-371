export const lectureData75 = {
  id: "7.5",
  title: "Fluidity and Asymmetry of Membranes",
  intro: "The plasma membrane is not a rigid structure; rather, it is a dynamic, flexible layer in constant motion. This fluidity is essential for membrane function, allowing diffusion of molecules, rapid signaling, and even cell movement. The concept of membrane fluidity arises from the lateral mobility of lipids and proteins within the bilayer.",
  sections: [
    {
      title: "1. Lipid Movement",
      content: "Lipids within the bilayer exhibit several types of motion:",
      listItems: [
        "Lateral diffusion: Movement of lipids within the same leaflet; occurs rapidly and frequently.",
        "Rotation: Lipid molecules rotate around their long axis, maintaining flexibility.",
        "Flexion: Fatty acid tails bend and adjust their conformations, influencing membrane thickness.",
        "Transverse diffusion (flip-flop): Rare spontaneous movement of lipids from one leaflet to the other, catalyzed by specific enzymes."
      ],
      additionalContent: "The flip-flop movement is thermodynamically unfavorable because it requires passing the hydrophilic head group through the hydrophobic core. Enzymes such as flippases, floppases, and scramblases facilitate this process. These enzymes are crucial for maintaining and adjusting lipid asymmetry, a property vital for cell signaling, apoptosis, and vesicle trafficking."
    },
    {
      title: "2. Factors Affecting Membrane Fluidity",
      listItems: [
        "Fatty Acid Composition: Unsaturated fatty acids introduce kinks that prevent tight packing, increasing fluidity. Saturated fatty acids make membranes more rigid.",
        "Temperature: As temperature increases, membranes become more fluid; at low temperatures, they can become gel-like.",
        "Cholesterol Content: Cholesterol acts as a fluidity buffer, preventing membranes from becoming too fluid at high temperatures or too rigid at low temperatures."
      ]
    },
    {
      title: "3. Transition Temperature (Tm)",
      content: [
        "Each membrane has a characteristic transition temperature (Tm), the point at which it shifts from a gel (solid) state to a fluid (liquid-crystalline) state. Membranes rich in unsaturated fatty acids have a lower Tm, while those rich in saturated fatty acids or cholesterol have a higher Tm.",
        "Organisms living in cold environments often adapt by increasing the proportion of unsaturated fatty acids in their membranes to maintain fluidity."
      ]
    },
    {
      title: "4. Membrane Asymmetry",
      content: [
        "The lipid composition of the two leaflets of a membrane is asymmetric — not identical in structure or function. This asymmetry is established during membrane synthesis and actively maintained by enzymatic mechanisms.",
        "Phosphatidylcholine and sphingomyelin are mainly on the outer leaflet. Phosphatidylserine, phosphatidylethanolamine, and phosphatidylinositol are mainly on the inner leaflet.",
        "This asymmetry contributes to electrical potential, signaling, and recognition. For example, exposure of phosphatidylserine on the outer leaflet acts as an 'eat-me' signal for macrophages during apoptosis."
      ]
    },
    {
      title: "5. Lateral Heterogeneity and Lipid Rafts",
      content: [
        "The membrane is not uniform; regions called lipid rafts are enriched in cholesterol, sphingolipids, and specific proteins. These microdomains serve as platforms for signal transduction, protein sorting, and membrane trafficking.",
        "Lipid rafts are more ordered and tightly packed than surrounding regions, yet they remain dynamic, forming and dispersing as needed.",
        "Overall, membrane fluidity and asymmetry are critical for the function, adaptability, and survival of cells, influencing everything from nutrient transport to cell communication."
      ]
    }
  ],
  tables: [
    {
      headers: ["Enzyme", "Direction", "Energy Requirement"],
      rows: [
        ["Flippase", "Outer → Inner leaflet", "ATP-dependent"],
        ["Floppase", "Inner → Outer leaflet", "ATP-dependent"],
        ["Scramblase", "Bidirectional (non-specific)", "ATP-independent (activated by Ca²⁺)"]
      ]
    }
  ],
  figures: [
    { number: "7-9", caption: "The dynamic nature of the lipid bilayer. Lipids and many proteins move laterally within the membrane, creating a fluid mosaic organization." },
    { number: "7-10", caption: "Cholesterol as a fluidity regulator. Cholesterol fits between phospholipid tails, stabilizing the bilayer by reducing extreme changes in fluidity." },
    { number: "7-11", caption: "Lipid asymmetry in biological membranes. Different lipid species are distributed unequally between the two leaflets, contributing to functional specialization." },
    { number: "7-12", caption: "Lipid rafts in membranes. Cholesterol- and sphingolipid-rich domains act as specialized regions for protein clustering and signaling." }
  ]
};

export const lectureData76 = {
  id: "7.6",
  title: "Membrane Dynamics and Transport",
  intro: "The plasma membrane is a dynamic barrier that regulates the controlled exchange of substances between the cell and its environment. Molecules move across membranes by several mechanisms that differ in energy requirement, direction, and specificity.",
  sections: [
    {
      title: "1. Passive Transport",
      content: [
        "Passive transport allows molecules to move across the membrane without the expenditure of cellular energy. Movement occurs down a concentration or electrochemical gradient until equilibrium is reached."
      ],
      listItems: [
        "Simple diffusion: Non-polar molecules such as O₂, CO₂, and small lipophilic compounds diffuse directly through the lipid bilayer.",
        "Facilitated diffusion: Polar or charged molecules cross the membrane with the help of specific transport proteins, including channels and carriers."
      ],
      additionalContent: "Channel proteins form hydrophilic pores through which specific ions or water molecules can pass rapidly. Carrier proteins bind the molecule on one side, undergo a conformational change, and release it on the other side."
    },
    {
      title: "2. Osmosis and Aquaporins",
      content: [
        "Water diffuses across membranes through specialized channels called aquaporins. Osmosis describes the net movement of water from regions of low solute concentration to regions of high solute concentration. This process is crucial for maintaining cell volume and turgor pressure in plant and animal cells.",
        "Cells maintain osmotic balance through ion pumps and osmolytes to prevent swelling or shrinkage."
      ]
    },
    {
      title: "3. Active Transport",
      content: [
        "Active transport moves molecules against their concentration or electrochemical gradient and therefore requires energy. This energy is usually supplied by ATP hydrolysis or by coupling to an existing gradient."
      ],
      listItems: [
        "Primary active transport: Direct use of metabolic energy (ATP) to drive solute movement.",
        "Secondary active transport: Indirect use of energy; one solute moves down its gradient to drive another uphill."
      ],
      additionalContent: [
        "The best-known primary pump is the sodium-potassium (Na⁺/K⁺-ATPase), which maintains the high intracellular K⁺ and low Na⁺ concentrations essential for membrane potential.",
        "Secondary active transporters include symporters and antiporters: Symport - Two solutes move in the same direction (e.g., Na⁺-glucose symporter). Antiport - Solutes move in opposite directions (e.g., Na⁺/Ca²⁺ exchanger)."
      ]
    },
    {
      title: "4. Endocytosis and Exocytosis",
      content: "Large macromolecules and particulate materials are transported via vesicular mechanisms. Endocytosis internalizes substances into vesicles derived from the plasma membrane, while exocytosis releases materials to the extracellular environment.",
      listItems: [
        "Phagocytosis: Cell eating; uptake of large particles such as bacteria by specialized cells (macrophages, neutrophils).",
        "Pinocytosis: Cell drinking; uptake of fluids and dissolved solutes by small vesicles.",
        "Receptor-mediated endocytosis: Highly selective uptake of specific molecules such as LDL or transferrin via coated pits containing clathrin."
      ]
    },
    {
      title: "5. Membrane Fusion and Vesicle Targeting",
      content: [
        "Membrane fusion is mediated by specialized proteins such as SNAREs and Rab GTPases, which ensure vesicles dock at the correct target membrane. Fusion allows delivery of vesicle contents and incorporation of membrane components into the destination organelle or plasma membrane.",
        "This process is vital for neurotransmitter release, hormone secretion, and recycling of membrane receptors."
      ]
    }
  ],
  tables: [
    {
      headers: ["Type", "Energy Use", "Direction", "Examples"],
      rows: [
        ["Simple Diffusion", "No", "Down gradient", "O₂, CO₂"],
        ["Facilitated Diffusion", "No", "Down gradient", "Glucose, ions via channels"],
        ["Primary Active Transport", "ATP", "Against gradient", "Na⁺/K⁺-ATPase"],
        ["Secondary Active Transport", "Indirect", "Against gradient", "Na⁺-Glucose symporter"],
        ["Endocytosis", "ATP", "Bulk inward", "Receptor-mediated LDL uptake"],
        ["Exocytosis", "ATP", "Bulk outward", "Neurotransmitter release"]
      ]
    }
  ],
  conclusion: "Membrane transport processes collectively maintain homeostasis, nutrient uptake, waste removal, and intercellular communication—functions essential to all forms of life.",
  figures: [
    { number: "7-13", caption: "Mechanisms of membrane transport. Molecules may cross passively through diffusion or require active, energy-dependent transport systems." },
    { number: "7-14", caption: "Facilitated diffusion. Transport proteins accelerate the movement of solutes without energy input, always moving down their gradient." },
    { number: "7-15", caption: "Na⁺/K⁺-ATPase pump. This pump hydrolyzes ATP to transport 3 Na⁺ ions out and 2 K⁺ ions into the cell per cycle, maintaining electrochemical balance." },
    { number: "7-15A", caption: "Secondary active transport mechanisms. Symporters move two molecules in the same direction, while antiporters move molecules in opposite directions, both driven by established concentration gradients." },
    { number: "7-16", caption: "Receptor-mediated endocytosis. Selective uptake of specific molecules through clathrin-coated pits and vesicle formation." },
    { number: "7-16A", caption: "Phagocytosis process. Specialized cells engulf large particles such as bacteria through pseudopod extension and phagosome formation." }
  ]
};

export const lectureData77 = {
  id: "7.7",
  title: "Experimental Insights and Techniques",
  intro: "Much of what we know about membrane structure and dynamics has come from a variety of experimental techniques. These methods allow researchers to visualize membranes, analyze their composition, and study the movement of lipids and proteins within them.",
  sections: [
    {
      title: "1. Electron Microscopy",
      content: [
        "The earliest insights into membrane structure were obtained using transmission electron microscopy (TEM). When membranes are stained with heavy metals, they appear as a trilaminar structure — two dark lines separated by a lighter region — known as the 'unit membrane.'",
        "Freeze-fracture electron microscopy provided further insights. In this technique, frozen cells are split along the hydrophobic plane of the lipid bilayer, revealing the inner surfaces of membranes. The fracture plane exposes protein particles embedded in the bilayer, offering direct evidence for the fluid mosaic model."
      ]
    },
    {
      title: "2. Fluorescence Recovery After Photobleaching (FRAP)",
      content: [
        "The FRAP technique is used to measure the mobility of membrane components. A specific region of a fluorescently labeled membrane is bleached with a laser beam. Over time, unbleached fluorescent molecules from surrounding areas move into the bleached spot, and the recovery of fluorescence is monitored.",
        "The rate of fluorescence recovery indicates the diffusion coefficient of the molecules, demonstrating that both lipids and proteins can move laterally within the membrane."
      ]
    },
    {
      title: "3. Fluorescence Resonance Energy Transfer (FRET)",
      content: [
        "FRET is used to study the proximity of membrane molecules. It involves two fluorophores — a donor and an acceptor — where energy transfer occurs only if the two are within a few nanometers. This allows determination of molecular interactions and conformational changes within living cells.",
        "FRET provides a powerful tool for analyzing receptor activation, protein clustering, and lipid microdomains in real time."
      ]
    },
    {
      title: "4. Atomic Force Microscopy (AFM)",
      content: [
        "AFM allows visualization of membranes and associated proteins at nanometer resolution without the need for staining or fixation. A sharp probe scans the membrane surface, measuring forces between the tip and the sample. This provides topographical maps of membrane roughness, protein distribution, and mechanical properties."
      ]
    },
    {
      title: "5. Detergent Solubilization and Reconstitution",
      content: [
        "Detergents are amphipathic molecules that can solubilize membranes by disrupting lipid–protein interactions. They are used to extract membrane proteins for biochemical analysis or to reconstitute artificial membranes for functional studies.",
        "Mild detergents such as Triton X-100 or CHAPS allow selective solubilization of certain membrane components while maintaining others in lipid rafts, revealing functional organization within membranes."
      ]
    },
    {
      title: "6. Liposome and Artificial Bilayer Studies",
      content: [
        "Artificial membranes, including liposomes (spherical vesicles composed of lipid bilayers), are widely used model systems. They enable the study of transport, fusion, and membrane protein function under controlled conditions.",
        "Liposomes can encapsulate substances, mimicking cellular compartments, and are also applied in drug delivery and nanomedicine research."
      ]
    },
    {
      title: "7. Modern Imaging and Spectroscopy Techniques",
      content: [
        "Advances in super-resolution microscopy, cryogenic electron microscopy (cryo-EM), and NMR spectroscopy have enabled visualization of membranes and proteins at near-atomic resolution.",
        "These methods provide insights into molecular interactions, protein conformational changes, and membrane remodeling processes during signaling, fusion, and endocytosis.",
        "Together, these experimental techniques have confirmed that biological membranes are dynamic, asymmetric, and molecularly complex structures—constantly reshaped to meet cellular demands."
      ]
    }
  ],
  figures: [
    { number: "7-17", caption: "The unit membrane structure. Electron microscopy reveals two electron-dense layers (the polar head groups) and a central lighter region (hydrophobic tails)." },
    { number: "7-18", caption: "Freeze-fracture micrograph. The technique exposes membrane interiors and shows scattered protein particles corresponding to integral membrane proteins." },
    { number: "7-19", caption: "FRAP analysis. Fluorescence returns to the bleached area as unbleached molecules diffuse laterally, quantifying membrane fluidity." },
    { number: "7-20", caption: "Atomic Force Microscopy. AFM generates three-dimensional surface profiles, revealing the height and organization of membrane proteins." },
    { number: "7-21", caption: "Liposome model systems. Synthetic vesicles replicate key structural and functional properties of biological membranes." }
  ]
};
