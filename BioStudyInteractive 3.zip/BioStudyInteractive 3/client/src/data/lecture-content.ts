export interface LectureContent {
  id: string;
  title: string;
  subsections?: {
    title: string;
    content: React.ReactNode;
  }[];
  figures?: {
    number: string;
    caption: string;
  }[];
  tables?: {
    headers: string[];
    rows: string[][];
  }[];
}

export const lectureData: Record<string, any> = {
  "7.1": {
    id: "7.1",
    title: "Introduction",
    subtitle: "Membranes: Their Structure, Function, and Chemistry",
    content: [
      "What defines a cell and its organelles? An essential feature of every cell is the presence of membranes—structures that define the boundaries of the cell and any internal compartments such as the nucleus, mitochondria, and chloroplasts of eukaryotic cells. Even the casual observer of electron micrographs is likely to be struck by the prominence of membranes around all cells and within cells of eukaryotic organisms.",
      "Each of these membranes not only defines the boundaries of the cell or organelle but also serves as a dynamic interface through which the cell interacts with its environment. Membranes are not merely barriers; they are active participants in a cell's life, supporting essential biological functions such as transport, signaling, and compartmentalization.",
      "All cellular membranes have a common structural organization and are composed of similar molecules. The lipids of a cell membrane form a bilayer that provides the basic structure of the membrane and serves as a barrier to the passage of most polar molecules and ions. Proteins are embedded within the lipid bilayer and are responsible for the specific functions of membranes, including the transport of molecules and ions into and out of the cell, the catalysis of chemical reactions, and the transmission of signals.",
      "Membranes are dynamic structures, fluid in nature, in which most of the individual lipid and protein molecules can move relatively freely. The composition of the lipids and proteins varies depending on the type of membrane and the cell or organelle it encloses. This dynamic organization is essential to maintain proper cell function, growth, and communication."
    ],
    figures: [
      {
        number: "7-1",
        caption: "A Lipid Bilayer. This molecular model shows a section of a typical lipid bilayer that forms the basis of biological membranes. Nonpolar hydrocarbon chains form the interior of the membrane, with polar head groups and associated water molecules at both surfaces."
      }
    ]
  },
  "7.2": {
    id: "7.2",
    title: "Functions of Membranes",
    content: [
      "Biological membranes perform several critical functions that are essential for cellular integrity, organization, and activity. These functions extend far beyond merely forming physical barriers; membranes act as highly dynamic and selective interfaces between the cell and its environment, controlling movement, communication, and energy transformation."
    ],
    sections: [
      {
        title: "1. Define Boundaries and Serve as Permeability Barriers",
        content: "Membranes define the boundaries of the cell and of its internal compartments such as the nucleus, endoplasmic reticulum, mitochondria, and chloroplasts. By enclosing specific environments, they allow different biochemical reactions to occur simultaneously in distinct spaces. These boundaries are selectively permeable—they prevent the unrestricted movement of molecules and ions while allowing the regulated exchange of specific substances."
      },
      {
        title: "2. Sites of Specific Proteins and Enzymatic Activities",
        content: "Membranes contain many proteins that function as enzymes or as components of enzymatic complexes. For example, the plasma membrane includes proteins involved in ATP hydrolysis and signal transduction, whereas the inner mitochondrial membrane houses enzymes for oxidative phosphorylation."
      },
      {
        title: "3. Regulation of Transport Processes",
        content: "The transport of solutes across membranes is one of the most important cellular processes. Transport proteins act as selective gates and pumps, mediating the movement of ions, nutrients, and waste products into and out of the cell or organelle. Passive diffusion, facilitated diffusion, and active transport all occur through these specialized proteins."
      },
      {
        title: "4. Detection and Transmission of Signals",
        content: "Membranes play a key role in cell communication through signal transduction. Specific receptor proteins embedded in the membrane receive external signals, such as hormones or neurotransmitters, and trigger a cascade of intracellular events leading to a physiological response."
      },
      {
        title: "5. Cell-to-Cell Recognition and Adhesion",
        content: "The carbohydrate components of glycoproteins and glycolipids on the outer surface of the plasma membrane function as recognition sites that allow cells to identify and interact with one another. These interactions are vital for tissue formation, immune responses, and developmental processes."
      },
      {
        title: "6. Energy Transduction",
        content: "Certain membranes, such as those in mitochondria and chloroplasts, are specialized for the conversion of energy. The electron transport chains embedded in these membranes allow the transformation of energy derived from food or sunlight into chemical energy in the form of ATP."
      },
      {
        title: "7. Compartmentalization and Organization of Chemical Reactions",
        content: "By segregating metabolic processes within distinct organelles, membranes allow cells to carry out incompatible reactions simultaneously. For example, the lysosomal membrane isolates hydrolytic enzymes from the cytoplasm, preventing unwanted degradation of cellular components."
      }
    ],
    conclusion: "In summary, membranes are not passive structures but active, highly organized systems that coordinate the flow of information, materials, and energy. Without membranes, the cell would lose its identity, control, and the ability to maintain homeostasis.",
    figures: [
      {
        number: "7-2",
        caption: "The central role of membranes. Membranes define the boundaries of cells and organelles and mediate communication and material exchange between them."
      }
    ]
  },
  "7.3": {
    id: "7.3",
    title: "Membrane Lipids",
    intro: "Lipids are the primary structural component of biological membranes. They provide the framework that ensures membrane integrity while allowing dynamic flexibility and selective permeability. The lipid composition of membranes varies considerably among organisms, tissues, and organelles, reflecting their specialized functions.",
    mainContent: "The most abundant lipids in membranes are phospholipids, followed by glycolipids and sterols. These amphipathic molecules have both hydrophobic and hydrophilic regions, a property that drives the spontaneous formation of bilayers in aqueous environments.",
    sections: [
      {
        title: "1. Phospholipids",
        content: [
          "Phospholipids consist of a glycerol backbone linked to two fatty acid chains and a phosphate-containing head group. The fatty acid tails are hydrophobic, whereas the phosphate and attached head group are hydrophilic. Depending on the head group, different classes of phospholipids exist: phosphatidylcholine, phosphatidylethanolamine, phosphatidylserine, and phosphatidylinositol.",
          "The composition of phospholipids affects membrane curvature, charge, and interactions with proteins. For instance, phosphatidylethanolamine promotes curvature necessary for vesicle formation, whereas phosphatidylserine contributes a negative charge important for protein binding."
        ]
      },
      {
        title: "2. Glycolipids",
        content: [
          "Glycolipids are derivatives of lipids that contain carbohydrate groups attached to the lipid head region. They are found predominantly on the extracellular leaflet of the plasma membrane and play crucial roles in cell recognition and signaling.",
          "The carbohydrate moieties of glycolipids serve as markers for cell identity and are often involved in interactions with bacterial toxins, viruses, and other cells. For example, gangliosides in nerve cells function as receptors for certain bacterial toxins such as cholera toxin."
        ]
      },
      {
        title: "3. Sterols",
        content: [
          "Sterols, such as cholesterol in animal cells, ergosterol in fungi, and phytosterols in plants, are essential components of membranes that modulate fluidity and stability. Cholesterol inserts between phospholipid molecules, reducing permeability and preventing excessive fluidity at high temperatures while avoiding rigidity at low temperatures.",
          "The relative amount of cholesterol and unsaturated fatty acids determines membrane fluidity. Membranes rich in unsaturated fatty acids remain fluid at lower temperatures, while those rich in saturated fatty acids become more rigid."
        ]
      },
      {
        title: "4. Amphipathic Nature and Bilayer Formation",
        content: [
          "The amphipathic nature of membrane lipids—having both hydrophobic and hydrophilic regions—drives their spontaneous arrangement into bilayers in aqueous solutions. The hydrophobic tails cluster together away from water, while the hydrophilic head groups face outward toward the aqueous environment. This self-assembly is driven primarily by hydrophobic interactions, stabilized by van der Waals forces and hydrogen bonding.",
          "The lipid bilayer serves as the fundamental matrix of all biological membranes. It forms a semi-permeable barrier that separates the cell interior from the extracellular environment and provides a stable but flexible platform for membrane proteins."
        ]
      }
    ],
    figures: [
      {
        number: "7-3",
        caption: "The major lipid classes of biological membranes. Most membranes contain phospholipids, glycolipids, and sterols in varying proportions, contributing to their physical and functional diversity."
      },
      {
        number: "7-4",
        caption: "Role of cholesterol in modulating membrane fluidity. Cholesterol reduces membrane permeability and helps maintain structural integrity across temperature changes."
      },
      {
        number: "7-5",
        caption: "The amphipathic organization of lipid bilayers. Hydrophilic heads face the aqueous environment, while hydrophobic tails form the bilayer interior."
      }
    ]
  },
  "7.4": {
    id: "7.4",
    title: "Membrane Proteins",
    intro: "While lipids provide the structural framework of membranes, proteins carry out most of the specific functions associated with them. The combination of lipids and proteins within the bilayer results in a complex, dynamic mosaic structure that supports communication, transport, recognition, and enzymatic activity.",
    mainContent: "Membrane proteins can be classified based on their location and interaction with the lipid bilayer into two main types: integral membrane proteins and peripheral membrane proteins. Some integral proteins that span the bilayer multiple times are also referred to as transmembrane proteins.",
    sections: [
      {
        title: "1. Integral (Intrinsic) Membrane Proteins",
        content: [
          "Integral membrane proteins are tightly bound to the lipid bilayer and can be removed only by disrupting the membrane with detergents or organic solvents. These proteins have one or more hydrophobic regions that interact with the membrane's hydrophobic core. They may extend across the membrane (transmembrane proteins) or be partially embedded on one side.",
          "Transmembrane proteins are the most functionally diverse, participating in transport, signal transduction, and energy conversion. Many contain hydrophobic α-helices that span the bilayer, while others form β-barrel structures, especially in the outer membranes of mitochondria, chloroplasts, and bacteria.",
          "The arrangement of hydrophobic and hydrophilic regions determines how these proteins orient within the membrane. The parts exposed to the aqueous environment typically contain hydrophilic amino acids, whereas the transmembrane regions contain hydrophobic amino acids that interact with lipid tails."
        ]
      },
      {
        title: "2. Peripheral (Extrinsic) Membrane Proteins",
        content: [
          "Peripheral membrane proteins are bound to the membrane surface through weak electrostatic interactions and hydrogen bonding with polar head groups or other proteins. They can be removed without disrupting the lipid bilayer, typically by altering pH or ionic strength.",
          "These proteins serve as enzymes, anchors for the cytoskeleton, or components of signaling pathways. Because they are not embedded in the hydrophobic core, they maintain a high degree of mobility along the membrane surface."
        ]
      },
      {
        title: "3. Lipid-Anchored Proteins",
        content: [
          "A third class, lipid-anchored proteins, are covalently attached to lipid molecules that embed in the bilayer. This anchorage allows them to associate strongly with membranes without having transmembrane domains.",
          "Examples include GPI-anchored proteins on the external membrane surface and prenylated proteins on the cytoplasmic side. These modifications play key roles in signaling, protein targeting, and membrane stability."
        ]
      },
      {
        title: "4. Functions of Membrane Proteins",
        listItems: [
          "Transport: Channels, carriers, and pumps regulate the passage of ions and molecules across the membrane.",
          "Enzymatic Activity: Many membrane proteins act as enzymes that catalyze specific reactions on the membrane surface.",
          "Signal Transduction: Receptors bind signaling molecules and transmit information to the cell interior.",
          "Cell Recognition: Glycoproteins serve as identification tags recognized by other cells.",
          "Intercellular Joining: Membrane proteins of adjacent cells may hook together in junctions.",
          "Attachment to Cytoskeleton and ECM: This stabilizes cell shape and maintains tissue organization."
        ]
      }
    ],
    conclusion: "In summary, membrane proteins transform the lipid bilayer from a simple barrier into an active, versatile interface that coordinates vital cellular processes.",
    figures: [
      {
        number: "7-6",
        caption: "The fluid mosaic model of membrane structure. Membrane proteins float within the lipid bilayer, forming a mosaic of functional components that move laterally within the plane of the membrane."
      },
      {
        number: "7-7",
        caption: "Transmembrane protein organization. Most span the bilayer as α-helices, but β-barrels are found in some bacterial and mitochondrial membranes."
      },
      {
        number: "7-8",
        caption: "Lipid-anchored proteins. Proteins can be covalently attached to fatty acids, prenyl groups, or GPI anchors to maintain association with the membrane."
      }
    ]
  }
};
