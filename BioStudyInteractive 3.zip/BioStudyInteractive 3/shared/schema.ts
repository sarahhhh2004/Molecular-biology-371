import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Quiz schemas
export const quizQuestionSchema = z.object({
  id: z.string(),
  question: z.string(),
  options: z.array(z.string()).length(4),
  correctAnswer: z.number().min(0).max(3),
  explanation: z.string(),
});

export const quizSubmissionSchema = z.object({
  answers: z.record(z.string(), z.number()),
});

export const quizResultSchema = z.object({
  score: z.number(),
  totalQuestions: z.number(),
  percentage: z.number(),
  correctAnswers: z.array(z.string()),
  incorrectAnswers: z.array(z.object({
    questionId: z.string(),
    userAnswer: z.number(),
    correctAnswer: z.number(),
    explanation: z.string(),
  })),
});

export type QuizQuestion = z.infer<typeof quizQuestionSchema>;
export type QuizSubmission = z.infer<typeof quizSubmissionSchema>;
export type QuizResult = z.infer<typeof quizResultSchema>;

// Mind map node type
export const mindMapNodeSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string(),
  color: z.string().optional(),
});

export type MindMapNode = z.infer<typeof mindMapNodeSchema>;

// Progress tracking tables
export const quizAttempts = pgTable("quiz_attempts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  score: integer("score").notNull(),
  totalQuestions: integer("total_questions").notNull(),
  percentage: integer("percentage").notNull(),
  answers: jsonb("answers").notNull().$type<Record<string, number>>(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const sectionProgress = pgTable("section_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  sectionId: text("section_id").notNull(),
  completed: boolean("completed").notNull().default(false),
  timeSpent: integer("time_spent").notNull().default(0),
  lastVisited: timestamp("last_visited").notNull().defaultNow(),
});

export const studySessions = pgTable("study_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  startTime: timestamp("start_time").notNull().defaultNow(),
  endTime: timestamp("end_time"),
  duration: integer("duration"),
});

export const insertQuizAttemptSchema = createInsertSchema(quizAttempts).omit({
  id: true,
  timestamp: true,
});

export const insertSectionProgressSchema = createInsertSchema(sectionProgress).omit({
  id: true,
  lastVisited: true,
});

export const insertStudySessionSchema = createInsertSchema(studySessions).omit({
  id: true,
  startTime: true,
});

export type InsertQuizAttempt = z.infer<typeof insertQuizAttemptSchema>;
export type QuizAttempt = typeof quizAttempts.$inferSelect;
export type InsertSectionProgress = z.infer<typeof insertSectionProgressSchema>;
export type SectionProgress = typeof sectionProgress.$inferSelect;
export type InsertStudySession = z.infer<typeof insertStudySessionSchema>;
export type StudySession = typeof studySessions.$inferSelect;
