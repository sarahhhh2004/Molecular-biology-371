import { QuizQuestion } from "../../shared/schema";

export const quizQuestions: QuizQuestion[] = [
  {
    id: "q1",
    question: "What is the primary structural component of biological membranes?",
    options: [
      "Carbohydrates",
      "Lipid bilayer",
      "Proteins",
      "Nucleic acids"
    ],
    correctAnswer: 1,
    explanation: "The lipid bilayer is the primary structural component, providing the basic framework and barrier properties of membranes."
  },
  {
    id: "q2",
    question: "Which type of lipid is most abundant in biological membranes?",
    options: [
      "Triglycerides",
      "Sterols",
      "Phospholipids",
      "Waxes"
    ],
    correctAnswer: 2,
    explanation: "Phospholipids are the most abundant lipids in membranes, followed by glycolipids and sterols."
  },
  {
    id: "q3",
    question: "What property of membrane lipids drives bilayer formation?",
    options: [
      "Hydrophilic nature",
      "Amphipathic nature",
      "Hydrophobic nature",
      "Charged nature"
    ],
    correctAnswer: 1,
    explanation: "The amphipathic nature—having both hydrophobic and hydrophilic regions—drives spontaneous bilayer formation in aqueous solutions."
  },
  {
    id: "q4",
    question: "Which molecule acts as a 'fluidity buffer' in membranes?",
    options: [
      "Phosphatidylcholine",
      "Glycolipids",
      "Cholesterol",
      "Sphingomyelin"
    ],
    correctAnswer: 2,
    explanation: "Cholesterol prevents membranes from becoming too fluid at high temperatures or too rigid at low temperatures."
  },
  {
    id: "q5",
    question: "What are integral membrane proteins?",
    options: [
      "Proteins loosely attached to membrane surfaces",
      "Proteins that span the lipid bilayer",
      "Proteins in the cytoplasm",
      "Proteins in the extracellular matrix"
    ],
    correctAnswer: 1,
    explanation: "Integral membrane proteins are tightly bound to the bilayer and often span it completely (transmembrane proteins)."
  },
  {
    id: "q6",
    question: "Which type of transport does NOT require energy?",
    options: [
      "Active transport",
      "Facilitated diffusion",
      "Sodium-potassium pump",
      "Endocytosis"
    ],
    correctAnswer: 1,
    explanation: "Facilitated diffusion is passive transport that moves molecules down their gradient without requiring ATP."
  },
  {
    id: "q7",
    question: "What is the function of aquaporins?",
    options: [
      "Transport ions",
      "Transport glucose",
      "Transport water",
      "Transport proteins"
    ],
    correctAnswer: 2,
    explanation: "Aquaporins are specialized channel proteins that facilitate rapid water movement across membranes."
  },
  {
    id: "q8",
    question: "The Na⁺/K⁺-ATPase pump is an example of which type of transport?",
    options: [
      "Simple diffusion",
      "Facilitated diffusion",
      "Primary active transport",
      "Osmosis"
    ],
    correctAnswer: 2,
    explanation: "The Na⁺/K⁺-ATPase uses ATP directly to pump ions against their concentration gradients (primary active transport)."
  },
  {
    id: "q9",
    question: "What is phagocytosis?",
    options: [
      "Cell drinking",
      "Cell eating",
      "Cell signaling",
      "Cell division"
    ],
    correctAnswer: 1,
    explanation: "Phagocytosis ('cell eating') is the uptake of large particles like bacteria by specialized cells such as macrophages."
  },
  {
    id: "q10",
    question: "Which enzyme facilitates lipid flip-flop from outer to inner leaflet?",
    options: [
      "Scramblase",
      "Flippase",
      "Floppase",
      "Lipase"
    ],
    correctAnswer: 1,
    explanation: "Flippase is an ATP-dependent enzyme that moves lipids from the outer to the inner leaflet of the membrane."
  },
  {
    id: "q11",
    question: "What does membrane asymmetry refer to?",
    options: [
      "Different proteins on each side",
      "Different lipid composition in each leaflet",
      "Uneven membrane thickness",
      "Varying membrane fluidity"
    ],
    correctAnswer: 1,
    explanation: "Membrane asymmetry means the lipid composition differs between the inner and outer leaflets of the bilayer."
  },
  {
    id: "q12",
    question: "Exposure of which lipid on the outer membrane signals apoptosis?",
    options: [
      "Phosphatidylcholine",
      "Sphingomyelin",
      "Phosphatidylserine",
      "Cholesterol"
    ],
    correctAnswer: 2,
    explanation: "Phosphatidylserine exposure on the outer leaflet acts as an 'eat-me' signal for macrophages during apoptosis."
  },
  {
    id: "q13",
    question: "What are lipid rafts?",
    options: [
      "Vesicles for transport",
      "Cholesterol- and sphingolipid-rich microdomains",
      "Damaged membrane regions",
      "Protein-free zones"
    ],
    correctAnswer: 1,
    explanation: "Lipid rafts are microdomains enriched in cholesterol and sphingolipids that serve as platforms for signaling and protein sorting."
  },
  {
    id: "q14",
    question: "Which factor increases membrane fluidity?",
    options: [
      "Saturated fatty acids",
      "Low temperature",
      "Unsaturated fatty acids",
      "High cholesterol"
    ],
    correctAnswer: 2,
    explanation: "Unsaturated fatty acids have kinks that prevent tight packing, thereby increasing membrane fluidity."
  },
  {
    id: "q15",
    question: "What is the transition temperature (Tm) of a membrane?",
    options: [
      "The melting point of proteins",
      "The temperature at which the membrane shifts from gel to fluid state",
      "The optimal temperature for enzymes",
      "The temperature at which lipids degrade"
    ],
    correctAnswer: 1,
    explanation: "Tm is the temperature at which the membrane transitions from a solid (gel) state to a fluid (liquid-crystalline) state."
  },
  {
    id: "q16",
    question: "Which technique measures lateral mobility of membrane components?",
    options: [
      "FRET",
      "FRAP",
      "AFM",
      "TEM"
    ],
    correctAnswer: 1,
    explanation: "FRAP (Fluorescence Recovery After Photobleaching) measures how quickly fluorescent molecules diffuse laterally within membranes."
  },
  {
    id: "q17",
    question: "What does the fluid mosaic model describe?",
    options: [
      "Rigid protein structures",
      "Proteins and lipids moving within the membrane",
      "Static membrane organization",
      "Membrane synthesis"
    ],
    correctAnswer: 1,
    explanation: "The fluid mosaic model describes membranes as dynamic structures with proteins floating in a fluid lipid bilayer."
  },
  {
    id: "q18",
    question: "Which membrane protein type requires detergents for removal?",
    options: [
      "Peripheral proteins",
      "Cytoplasmic proteins",
      "Integral proteins",
      "Extracellular proteins"
    ],
    correctAnswer: 2,
    explanation: "Integral proteins are embedded in the bilayer and require detergents to disrupt lipid-protein interactions for removal."
  },
  {
    id: "q19",
    question: "What is receptor-mediated endocytosis?",
    options: [
      "Random uptake of fluids",
      "Selective uptake via specific receptors",
      "Release of neurotransmitters",
      "Passive diffusion"
    ],
    correctAnswer: 1,
    explanation: "Receptor-mediated endocytosis is the selective uptake of specific molecules (like LDL) via receptor binding and clathrin-coated pits."
  },
  {
    id: "q20",
    question: "Which proteins mediate membrane fusion in vesicle transport?",
    options: [
      "Aquaporins",
      "SNAREs",
      "Integrins",
      "Cadherins"
    ],
    correctAnswer: 1,
    explanation: "SNARE proteins ensure vesicles dock at the correct target membrane and mediate fusion for content delivery."
  },
  {
    id: "q21",
    question: "What is the role of glycoproteins in membranes?",
    options: [
      "Energy production",
      "Cell recognition and signaling",
      "Lipid synthesis",
      "DNA replication"
    ],
    correctAnswer: 1,
    explanation: "Glycoproteins serve as identification tags for cell recognition, immune responses, and cell-cell interactions."
  },
  {
    id: "q22",
    question: "Which membrane component is primarily responsible for selective permeability?",
    options: [
      "Carbohydrates",
      "The lipid bilayer",
      "Cholesterol only",
      "Water"
    ],
    correctAnswer: 1,
    explanation: "The lipid bilayer acts as a barrier to most polar molecules and ions, providing selective permeability."
  },
  {
    id: "q23",
    question: "What is osmosis?",
    options: [
      "Movement of ions through channels",
      "Active transport of glucose",
      "Net movement of water across membranes",
      "Protein synthesis"
    ],
    correctAnswer: 2,
    explanation: "Osmosis is the net movement of water from regions of low solute concentration to high solute concentration."
  },
  {
    id: "q24",
    question: "Which type of secondary active transport moves two solutes in the same direction?",
    options: [
      "Antiport",
      "Uniport",
      "Symport",
      "Channel"
    ],
    correctAnswer: 2,
    explanation: "Symporters move two solutes in the same direction, such as the Na⁺-glucose symporter."
  },
  {
    id: "q25",
    question: "What advantage does freeze-fracture electron microscopy provide?",
    options: [
      "Viewing live cells",
      "Exposing protein particles in the bilayer interior",
      "Measuring fluidity",
      "Determining lipid composition"
    ],
    correctAnswer: 1,
    explanation: "Freeze-fracture splits membranes along the hydrophobic plane, revealing embedded protein particles and supporting the fluid mosaic model."
  },
  {
    id: "q26",
    question: "What are liposomes used for in research?",
    options: [
      "Studying protein synthesis",
      "Modeling membrane transport and fusion",
      "DNA sequencing",
      "Enzyme kinetics only"
    ],
    correctAnswer: 1,
    explanation: "Liposomes are artificial lipid bilayer vesicles used to study membrane properties, transport, and drug delivery."
  },
  {
    id: "q27",
    question: "How do organisms in cold environments maintain membrane fluidity?",
    options: [
      "Increase saturated fatty acids",
      "Increase unsaturated fatty acids",
      "Decrease cholesterol",
      "Reduce protein content"
    ],
    correctAnswer: 1,
    explanation: "Cold-adapted organisms increase unsaturated fatty acids in their membranes to maintain fluidity at lower temperatures."
  },
  {
    id: "q28",
    question: "Which structure do most transmembrane proteins form to span the bilayer?",
    options: [
      "β-sheets only",
      "Random coils",
      "α-helices",
      "Triple helices"
    ],
    correctAnswer: 2,
    explanation: "Most transmembrane proteins contain hydrophobic α-helices that span the bilayer, though some form β-barrels."
  },
  {
    id: "q29",
    question: "What is the primary function of the glycocalyx?",
    options: [
      "Energy storage",
      "Protection and cell recognition",
      "DNA replication",
      "Lipid synthesis"
    ],
    correctAnswer: 1,
    explanation: "The glycocalyx, formed by carbohydrate chains on glycoproteins and glycolipids, protects cells and mediates recognition."
  },
  {
    id: "q30",
    question: "What does FRET measure in membrane studies?",
    options: [
      "Membrane thickness",
      "Lipid composition",
      "Proximity of molecules (nanometer scale)",
      "Temperature changes"
    ],
    correctAnswer: 2,
    explanation: "FRET (Fluorescence Resonance Energy Transfer) measures molecular proximity within a few nanometers, revealing interactions and conformational changes."
  }
];
