import { type User, type InsertUser, type QuizQuestion, type QuizSubmission, type QuizResult, type QuizAttempt, type InsertQuizAttempt, type SectionProgress, type InsertSectionProgress, type StudySession, type InsertStudySession } from "@shared/schema";
import { randomUUID } from "crypto";
import { quizQuestions } from "./data/quiz-questions";
import { db } from "./db";
import { quizAttempts, sectionProgress, studySessions, users } from "@shared/schema";
import { eq, desc, and, isNull } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Quiz methods
  getAllQuizQuestions(): Promise<QuizQuestion[]>;
  gradeQuiz(submission: QuizSubmission, userId?: string): Promise<QuizResult>;
  
  // Progress tracking methods
  saveQuizAttempt(attempt: InsertQuizAttempt): Promise<QuizAttempt>;
  getQuizAttempts(userId?: string, limit?: number): Promise<QuizAttempt[]>;
  getQuizStats(userId?: string): Promise<{ totalAttempts: number; averageScore: number; bestScore: number }>;
  
  updateSectionProgress(progress: InsertSectionProgress): Promise<SectionProgress>;
  getSectionProgress(userId?: string): Promise<SectionProgress[]>;
  getSectionProgressBySectionId(sectionId: string, userId?: string): Promise<SectionProgress | undefined>;
  
  startStudySession(userId?: string): Promise<StudySession>;
  endStudySession(sessionId: string, duration: number): Promise<StudySession>;
  getStudySessions(userId?: string, limit?: number): Promise<StudySession[]>;
}

export class DbStorage implements IStorage {
  private quizQuestions: QuizQuestion[];

  constructor() {
    this.quizQuestions = quizQuestions;
  }

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getAllQuizQuestions(): Promise<QuizQuestion[]> {
    // Return questions without the correct answers for security
    return this.quizQuestions.map(q => ({
      id: q.id,
      question: q.question,
      options: q.options,
      correctAnswer: -1, // Don't expose correct answer to client
      explanation: "" // Don't expose explanation until graded
    }));
  }

  async gradeQuiz(submission: QuizSubmission, userId?: string): Promise<QuizResult> {
    let correctCount = 0;
    const correctAnswers: string[] = [];
    const incorrectAnswers: Array<{
      questionId: string;
      userAnswer: number;
      correctAnswer: number;
      explanation: string;
    }> = [];

    this.quizQuestions.forEach((question) => {
      const userAnswer = submission.answers[question.id];
      
      if (userAnswer !== undefined) {
        if (userAnswer === question.correctAnswer) {
          correctCount++;
          correctAnswers.push(question.id);
        } else {
          incorrectAnswers.push({
            questionId: question.id,
            userAnswer,
            correctAnswer: question.correctAnswer,
            explanation: question.explanation,
          });
        }
      }
    });

    const totalQuestions = this.quizQuestions.length;
    const percentage = (correctCount / totalQuestions) * 100;

    // Save the attempt to database
    const attemptData: InsertQuizAttempt = {
      userId: userId || null,
      score: correctCount,
      totalQuestions,
      percentage: Math.round(percentage),
      answers: submission.answers,
    };
    await this.saveQuizAttempt(attemptData);

    return {
      score: correctCount,
      totalQuestions,
      percentage,
      correctAnswers,
      incorrectAnswers,
    };
  }

  async saveQuizAttempt(attempt: InsertQuizAttempt): Promise<QuizAttempt> {
    const [savedAttempt] = await db.insert(quizAttempts).values(attempt).returning();
    return savedAttempt;
  }

  async getQuizAttempts(userId?: string, limit: number = 10): Promise<QuizAttempt[]> {
    if (userId) {
      return await db
        .select()
        .from(quizAttempts)
        .where(eq(quizAttempts.userId, userId))
        .orderBy(desc(quizAttempts.timestamp))
        .limit(limit);
    } else {
      // Get all attempts (for anonymous users)
      return await db
        .select()
        .from(quizAttempts)
        .where(isNull(quizAttempts.userId))
        .orderBy(desc(quizAttempts.timestamp))
        .limit(limit);
    }
  }

  async getQuizStats(userId?: string): Promise<{ totalAttempts: number; averageScore: number; bestScore: number }> {
    const attempts = await this.getQuizAttempts(userId, 100);
    
    if (attempts.length === 0) {
      return { totalAttempts: 0, averageScore: 0, bestScore: 0 };
    }

    const totalAttempts = attempts.length;
    const averageScore = Math.round(attempts.reduce((sum, a) => sum + a.percentage, 0) / totalAttempts);
    const bestScore = Math.max(...attempts.map(a => a.percentage));

    return { totalAttempts, averageScore, bestScore };
  }

  async updateSectionProgress(progress: InsertSectionProgress): Promise<SectionProgress> {
    // Check if progress exists
    const existing = await this.getSectionProgressBySectionId(progress.sectionId, progress.userId || undefined);
    
    if (existing) {
      // Update existing progress
      const [updated] = await db
        .update(sectionProgress)
        .set({
          completed: progress.completed,
          timeSpent: existing.timeSpent + progress.timeSpent,
          lastVisited: new Date(),
        })
        .where(eq(sectionProgress.id, existing.id))
        .returning();
      return updated;
    } else {
      // Create new progress entry
      const [created] = await db.insert(sectionProgress).values(progress).returning();
      return created;
    }
  }

  async getSectionProgress(userId?: string): Promise<SectionProgress[]> {
    if (userId) {
      return await db
        .select()
        .from(sectionProgress)
        .where(eq(sectionProgress.userId, userId));
    } else {
      return await db
        .select()
        .from(sectionProgress)
        .where(isNull(sectionProgress.userId));
    }
  }

  async getSectionProgressBySectionId(sectionId: string, userId?: string): Promise<SectionProgress | undefined> {
    const where = userId 
      ? and(eq(sectionProgress.sectionId, sectionId), eq(sectionProgress.userId, userId))
      : and(eq(sectionProgress.sectionId, sectionId), isNull(sectionProgress.userId));

    const [progress] = await db
      .select()
      .from(sectionProgress)
      .where(where!);
    
    return progress;
  }

  async startStudySession(userId?: string): Promise<StudySession> {
    const [session] = await db
      .insert(studySessions)
      .values({ userId: userId || null })
      .returning();
    return session;
  }

  async endStudySession(sessionId: string, duration: number): Promise<StudySession> {
    const [updated] = await db
      .update(studySessions)
      .set({
        endTime: new Date(),
        duration,
      })
      .where(eq(studySessions.id, sessionId))
      .returning();
    return updated;
  }

  async getStudySessions(userId?: string, limit: number = 10): Promise<StudySession[]> {
    if (userId) {
      return await db
        .select()
        .from(studySessions)
        .where(eq(studySessions.userId, userId))
        .orderBy(desc(studySessions.startTime))
        .limit(limit);
    } else {
      return await db
        .select()
        .from(studySessions)
        .where(isNull(studySessions.userId))
        .orderBy(desc(studySessions.startTime))
        .limit(limit);
    }
  }
}

export const storage = new DbStorage();
