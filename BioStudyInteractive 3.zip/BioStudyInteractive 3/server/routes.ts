import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { quizSubmissionSchema, insertSectionProgressSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Quiz routes
  app.get("/api/quiz/questions", async (_req, res) => {
    try {
      const questions = await storage.getAllQuizQuestions();
      res.json(questions);
    } catch (error) {
      console.error("Error fetching quiz questions:", error);
      res.status(500).json({ error: "Failed to fetch quiz questions" });
    }
  });

  app.post("/api/quiz/submit", async (req, res) => {
    try {
      const submission = quizSubmissionSchema.parse(req.body);
      const userId = req.user?.id; // Get user ID if authenticated
      const result = await storage.gradeQuiz(submission, userId);
      res.json(result);
    } catch (error) {
      console.error("Error grading quiz:", error);
      res.status(400).json({ error: "Invalid quiz submission" });
    }
  });

  // Progress tracking routes
  app.get("/api/progress/quiz", async (req, res) => {
    try {
      const userId = req.user?.id;
      const limit = parseInt(req.query.limit as string) || 10;
      const attempts = await storage.getQuizAttempts(userId, limit);
      res.json(attempts);
    } catch (error) {
      console.error("Error fetching quiz attempts:", error);
      res.status(500).json({ error: "Failed to fetch quiz attempts" });
    }
  });

  app.get("/api/progress/stats", async (req, res) => {
    try {
      const userId = req.user?.id;
      const stats = await storage.getQuizStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching quiz stats:", error);
      res.status(500).json({ error: "Failed to fetch quiz stats" });
    }
  });

  app.get("/api/progress/sections", async (req, res) => {
    try {
      const userId = req.user?.id;
      const progress = await storage.getSectionProgress(userId);
      res.json(progress);
    } catch (error) {
      console.error("Error fetching section progress:", error);
      res.status(500).json({ error: "Failed to fetch section progress" });
    }
  });

  app.post("/api/progress/sections", async (req, res) => {
    try {
      const userId = req.user?.id;
      const progressData = insertSectionProgressSchema.parse({
        ...req.body,
        userId: userId || null,
      });
      const progress = await storage.updateSectionProgress(progressData);
      res.json(progress);
    } catch (error) {
      console.error("Error updating section progress:", error);
      res.status(400).json({ error: "Invalid section progress data" });
    }
  });

  app.post("/api/progress/session/start", async (req, res) => {
    try {
      const userId = req.user?.id;
      const session = await storage.startStudySession(userId);
      res.json(session);
    } catch (error) {
      console.error("Error starting study session:", error);
      res.status(500).json({ error: "Failed to start study session" });
    }
  });

  app.post("/api/progress/session/end", async (req, res) => {
    try {
      const { sessionId, duration } = req.body;
      if (!sessionId || typeof duration !== 'number') {
        return res.status(400).json({ error: "Invalid session data" });
      }
      const session = await storage.endStudySession(sessionId, duration);
      res.json(session);
    } catch (error) {
      console.error("Error ending study session:", error);
      res.status(400).json({ error: "Failed to end study session" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
