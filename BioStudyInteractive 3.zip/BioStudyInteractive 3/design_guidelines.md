# Design Guidelines: Cell Biology 383 Interactive Study Website

## Design Approach
**Educational Design System Approach** - Drawing from academic platforms like Khan Academy, Coursera, and scientific journals, prioritizing readability, clear hierarchy, and focused learning experiences. Blue-and-white color scheme as specified for professional academic presentation.

## Typography System

**Font Families:**
- Headings: Inter or similar geometric sans-serif (700, 600 weights)
- Body Text: Georgia or system serif for optimal readability in long-form scientific content (400, 600 weights)
- Code/Technical Terms: 'Courier New' or monospace for chemical formulas

**Type Scale:**
- Page Title (h1): text-4xl md:text-5xl, font-bold
- Section Headers (h2): text-3xl md:text-4xl, font-semibold
- Subsections (h3): text-xl md:text-2xl, font-semibold
- Body Text: text-base md:text-lg, line-height relaxed (1.7)
- Captions/Footnotes: text-sm

## Layout System

**Spacing Primitives:** Use Tailwind units of 4, 6, 8, 12, 16 for consistent rhythm
- Section padding: py-12 md:py-16
- Component spacing: gap-6 to gap-8
- Card padding: p-6 md:p-8
- Inline spacing: space-x-4, space-y-6

**Content Width:**
- Main content: max-w-4xl (optimal for reading scientific text)
- Quiz/Interactive sections: max-w-5xl
- Navigation sidebar: w-64 lg:w-72

**Grid Structure:**
- Single column for lecture content (readability priority)
- 2-column for mind map nodes (md:grid-cols-2)
- 1-column quiz with full-width question cards

## Component Library

### Navigation Header
- Fixed top navigation with course title, section dropdown
- Breadcrumb trail showing current location (Home > Lecture 7 > Section 7.3)
- Sticky behavior with subtle shadow on scroll
- Progress indicator showing completion through sections

### Lecture Content Sections
- Numbered section headers with anchor links
- Figure placeholders: bordered containers with dashed outlines, centered figcaption below
- Table placeholders: full-width responsive tables with alternating row styling
- Scientific term emphasis: bold for first occurrence, italic for Latin names
- Quote blocks for key definitions with left border accent

### Interactive Mind Map
- Grid of clickable node cards (rounded-xl, shadow-md)
- Each node: icon + title + brief description
- Connected with subtle dotted lines (decorative, CSS)
- Hover state: slight elevation (shadow-lg), scale transform
- Info panel below showing detailed explanation when node clicked

### Quiz System
- Question cards with numbered headers
- Radio button groups for multiple choice (large touch targets)
- Submit button: prominent, full-width on mobile
- Feedback system: inline correct/incorrect indicators with explanations
- Score summary card at completion with percentage and review option

### Sidebar Navigation (Desktop)
- Persistent left sidebar listing all sections 7.1-7.7
- Active section highlighted
- Collapse/expand for subsections
- Quick links to Quiz and Mind Map at bottom

### Footer
- Multi-column layout: Course info | Resources | Contact
- Copyright notice
- Links to previous/next lectures

## Interactive Elements

**Mind Map Interactions:**
- Click to reveal detailed explanations in expandable panel
- Visual connection highlighting when node active
- Reset button to clear selection

**Quiz Mechanics:**
- Immediate feedback after submission
- Color-coded results (semantic indicators, not just colors)
- Retry option without page reload
- Progress saving indication

**Figure/Table Interactions:**
- Placeholder text: "Figure 7-X will appear here" with descriptive alt text
- Click to expand (if actual images added later)
- Smooth zoom transitions

## Responsive Behavior

**Mobile (base):**
- Single column stack
- Hamburger menu for section navigation
- Collapsed sidebar becomes drawer
- Mind map: single column node stack
- Quiz: full-width cards with ample touch spacing

**Tablet (md: 768px+):**
- Sidebar appears as drawer (toggle)
- Mind map: 2-column grid
- Increased margins and padding

**Desktop (lg: 1024px+):**
- Persistent sidebar navigation
- Content centered with comfortable margins
- Mind map: up to 3 columns for large screens

## Images

**Hero Section:**
- NOT REQUIRED - This is a utility-focused study tool, not a marketing page
- Instead: Clean header with course title, lecture number, and topic overview

**Content Images:**
- Figure placeholders throughout lecture sections for scientific diagrams (lipid bilayer structures, membrane proteins, etc.)
- Mind map nodes: Small illustrative icons (molecules, transport arrows, cellular structures)
- Use simple line-art scientific illustrations when images added
- All images: responsive, with proper captions and figure numbers

## Accessibility Features

- ARIA labels for all interactive elements
- Keyboard navigation for mind map (arrow keys between nodes)
- Focus indicators on all clickable elements
- Semantic HTML throughout (<article>, <section>, <nav>)
- High contrast between text and backgrounds
- Skip links for keyboard users